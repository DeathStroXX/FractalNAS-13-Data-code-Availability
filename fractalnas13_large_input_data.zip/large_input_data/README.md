# FractalNAS-13: large input logs

These are the 34 pipeline pod logs of the October 2026 search runs behind the paper
*Evaluating LLM-Written Operators in Evolutionary Neural Architecture Search: Acceptance Rules and Search-Configuration Effects*.
They are about 330 MB uncompressed, which is too large for the Overleaf project and for the
main code repository, so they are distributed separately as this package
(Zenodo, doi:10.5281/zenodo.24261318, which always points to the latest version).

Everything else the paper needs (the manuscript sources, the analysis scripts, the 130 smaller
run logs in `logs/`, the data, tables and figures) is in the main paper folder and does not
depend on this package to compile.

## What needs these logs

Only a full rebuild of the results from the raw logs (`make all`). Three steps read the pod logs:

- the split of each run into its five segments (`analysis/common.py`, `segments()`),
- the learning curves (`analysis/s14_learning_curves.py`) and the search-space step
  (`analysis/s28_space.py`),
- the accuracy-floor truncation rates (`analysis/s69_censoring.py`).

Compiling the paper and running `make verify` do not need them.

## Layout

```
large_input_data/
  README.md
  SHA256SUMS
  pod_logs/<arm>/<dataset>/seed<N>_<uuid>/<timestamp>_<dataset>_<arm>_Pod_logs.log
```

- `<arm>` is one of `baseline`, `frozen`, `deepseek`, `mistral`, `qwen`.
- `<dataset>` is `cifar10` or `cifar100`.
- There is one log per run: 6 baseline, 10 frozen and 18 LLM-operator runs (34 in total).
- The run folder names match the ones under `logs/` in the main paper folder.

## How to use

Unpack the archive so that this folder sits next to `analysis/` and `logs/` in the paper folder:

```
<paper folder>/
  analysis/
  logs/
  large_input_data/pod_logs/...
```

The scripts find it there automatically. To keep the logs somewhere else, point the
`NAS_POD_LOGS` environment variable at the `pod_logs` directory.

Check the files after unpacking:

```
cd large_input_data
sha256sum -c SHA256SUMS
```

## Provenance

The logs are unmodified pipeline output. The same 34 files, byte for byte, are also part of
the research-input package of the companion paper, which analyses the same runs.

## Licence

Creative Commons Attribution 4.0 International (CC BY 4.0).
